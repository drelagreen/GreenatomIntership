create function checkworldrecord() returns trigger
    language plpgsql
as
$$
declare
        res int;
        id int;
        comp_id int;
begin
    if tg_op= 'INSERT' then
        begin
    id = (select max(result_id) from result);
    comp_id = (select max(competition_id) from result where result_id = id);
    res = (select max(result) from result where result_id = id);
    if (select max(world_record) from competition where competition_id = comp_id) < res then
        begin
        update competition set
                            world_record = res,
                            set_date = (select max(hold_date) from result where result_id = id)
        where competition_id = comp_id ;
        end;
    end if;
    end;
    end if;
    return null;
end
$$;

alter function checkworldrecord() owner to postgres;

